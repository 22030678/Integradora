/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package integradora;

import database.conexion;

/**
 *
 * @author rafae
 */
public class Integradora {

    /**
     * @param args the command line arguments
     */
    public static void main (String[] args) {
        
        // TODO code application logic here
        conexion conex=new conexion();
        conex.getConexion();
    }
    
}

ublic class Integradora {

    /**
     * @param args the command line arguments
     */
    public static void main (String[] args) {
//instalamos la interfaz principal
loguin logueo=new loguin();
logueo.setVisible (b:true);
}
}

